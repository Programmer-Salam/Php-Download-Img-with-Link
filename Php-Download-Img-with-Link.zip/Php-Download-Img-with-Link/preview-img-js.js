//Selecting the Image URL Input
const URLinput = document.getElementById('image_url')
//Selecting the Image Preview Panel Element
const ImagePreviewEl = document.getElementById('img-preview-panel')
//Selecting the Image Preview Container Element
const previewContainer = ImagePreviewEl.querySelector('.img-prev-holder')
//Selecting the Form Element
const form = document.querySelector('form')
//Selecting the Form Download button
const DownloadButton = form.querySelector('button[type="submit"]')
//Selecting the Image Preview Close/Reset Button
const resetPreviewBtn = ImagePreviewEl.querySelector('.prev-close-btn')

/** Event Listener when URL Input is updated */
URLinput.addEventListener('input', async e => {
    // Getting the Image URL Input Value
    var _url = URLinput.value
    // Regular Expresion for validating the Image URL
    var validURLRegEx = /^(http|https)\:\/\/(.*?)\.(jpe?g|png|gif)$/i;

    //Validating the Image URL
    var _urlIsValid = validURLRegEx.test(_url)
    
    if(_urlIsValid){
        // IF URL is valid Then preview Image
        var _img = document.createElement('img')
        _img.setAttribute('alt', 'Image to Download')
        _img.src = _url
        previewContainer.innerHTML = ''
        previewContainer.appendChild(_img)
        if(!ImagePreviewEl.classList.contains('filled'))
            ImagePreviewEl.classList.add('filled');
    }
    //Removing the disabled attribute from the Download Button
    if(DownloadButton.hasAttribute('disabled'))
    DownloadButton.removeAttribute('disabled')
})

/** Event Listener to reset the form */
resetPreviewBtn.addEventListener('click', e => {
    e.preventDefault()
    //Disabling the download button
    DownloadButton.setAttribute('disabled','')
    //Remove the url from input
    URLinput.value = ''
    //Mark Preview panel as unfilled by removing the filled class
    if(ImagePreviewEl.classList.contains('filled'))
            ImagePreviewEl.classList.remove('filled');
    URLinput.focus()
})