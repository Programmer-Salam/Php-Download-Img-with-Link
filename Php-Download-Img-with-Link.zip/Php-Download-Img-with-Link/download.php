<?php
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $imgURL = $_POST['image_url'];
    $curl_init = curl_init($imgURL);
    curl_setopt($curl_init, CURLOPT_RETURNTRANSFER, true);    
    $content = curl_exec($curl_init);
    curl_setopt($curl_init, CURLOPT_HEADER, true);    
    curl_setopt($curl_init, CURLOPT_NOBODY, true);
    $httpcode = curl_getinfo($curl_init, CURLINFO_HTTP_CODE);
    curl_close($curl_init);
    if($httpcode == 200){
        header('Content-TypeL image/png');
        header('Content-Disposition: attachement; filename="downloadedImage.png"');
        echo $content;
        header('location:./');
    }else{
        echo "<script>alert('Image URL is not Valid!')</script>";
        header('location:./');
    }
}
?>